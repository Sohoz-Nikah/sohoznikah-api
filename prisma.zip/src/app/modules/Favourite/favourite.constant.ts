export const FavouriteSearchAbleFields: string[] = ['name'];

export const FavouriteFilterableFields: string[] = [
  'searchTerm',
  'type',
  'status',
];
