export type IFavouriteFilterRequest = {
  searchTerm?: string | undefined;
  type?: string | undefined;
  status?: string | undefined;
};
