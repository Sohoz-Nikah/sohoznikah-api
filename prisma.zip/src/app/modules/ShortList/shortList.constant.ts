export const ShortlistSearchAbleFields: string[] = ['name'];

export const ShortlistFilterableFields: string[] = ['searchTerm'];
