export type IShortlistFilterRequest = {
  searchTerm?: string | undefined;
};
