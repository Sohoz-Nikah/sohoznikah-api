export const TokenSearchAbleFields: string[] = ['name'];

export const TokenFilterableFields: string[] = ['searchTerm', 'type', 'status'];
