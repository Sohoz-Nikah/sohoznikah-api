export type ITokenFilterRequest = {
  searchTerm?: string | undefined;
  status?: string | undefined;
};
