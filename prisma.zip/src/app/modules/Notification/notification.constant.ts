export const NotificationSearchAbleFields: string[] = ['type'];

export const NotificationFilterableFields: string[] = ['searchTerm', 'userId'];
