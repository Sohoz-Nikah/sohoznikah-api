export type INotificationFilterRequest = {
  searchTerm?: string | undefined;
  userId?: string | undefined;
};
