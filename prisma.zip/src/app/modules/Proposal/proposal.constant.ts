export const ProposalSearchAbleFields: string[] = ['name'];

export const ProposalFilterableFields: string[] = [
  'searchTerm',
  'type',
  'status',
];
