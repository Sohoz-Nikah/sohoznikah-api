export type IProposalFilterRequest = {
  searchTerm?: string | undefined;
  type?: string | undefined;
  status?: string | undefined;
};
