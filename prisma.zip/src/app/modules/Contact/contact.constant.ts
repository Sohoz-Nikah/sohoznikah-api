export const ContactSearchAbleFields: string[] = ['name'];

export const ContactFilterableFields: string[] = [
  'searchTerm',
  'type',
  'status',
];
