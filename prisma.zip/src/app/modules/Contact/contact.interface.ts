export type IContactFilterRequest = {
  searchTerm?: string | undefined;
  type?: string | undefined;
  status?: string | undefined;
};
