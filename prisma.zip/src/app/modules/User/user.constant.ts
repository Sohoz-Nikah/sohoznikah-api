export const UserSearchAbleFields: string[] = ['name'];

export const UserFilterableFields: string[] = [
  'name',
  'email',
  'role',
  'searchTerm',
];
