export type IUserFilterRequest = {
  searchTerm?: string | undefined;
};
