-- AlterTable
ALTER TABLE "BiodataSpousePreferenceInfo" ADD COLUMN     "blackSkinInterest" TEXT;
