-- AlterTable
ALTER TABLE "BiodataSpousePreferenceInfo" ALTER COLUMN "occupation" DROP NOT NULL,
ALTER COLUMN "occupation" SET DATA TYPE TEXT;
